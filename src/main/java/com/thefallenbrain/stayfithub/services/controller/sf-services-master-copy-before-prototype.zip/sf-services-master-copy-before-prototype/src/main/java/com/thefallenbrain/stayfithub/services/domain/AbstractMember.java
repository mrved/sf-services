package com.thefallenbrain.stayfithub.services.domain;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public abstract class AbstractMember {



}
