package com.thefallenbrain.stayfithub.services.domain;

public class MemberOptions {
}
